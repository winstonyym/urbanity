# Extracts images with Mapillary API V4 and computes semantic indicators
# GPU usage is recommended for semantic segmentation task
# requires mercantile, mapbox-vector-tile, vt2geojson, downgrade protobuf to 3.20





