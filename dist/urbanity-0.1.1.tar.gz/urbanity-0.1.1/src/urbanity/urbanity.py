def printsomething():
    return('This package has been created successfully.')
