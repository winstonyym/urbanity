# urbanity

Urbanity is a python package to model and understand urban complexity. This package is currently under development.

## Installation

```Terminal
$ pip install urbanity
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`urbanity` was created by winstonyym. It is licensed under the terms of the MIT license.

## Credits

`urbanity` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
